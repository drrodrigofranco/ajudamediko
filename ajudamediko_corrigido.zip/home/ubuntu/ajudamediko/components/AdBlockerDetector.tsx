import React, { useState, useEffect } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface AdBlockerDetectorProps {
  onDetected: (detected: boolean) => void;
}

const AdBlockerDetector: React.FC<AdBlockerDetectorProps> = ({ onDetected }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Lógica de detecção de AdBlocker
    const adBait = document.createElement('div');
    adBait.innerHTML = '&nbsp;';
    adBait.className = 'adsbox'; // Classe comum para contêineres de anúncios
    Object.assign(adBait.style, {
        position: 'absolute',
        top: '-9999px',
        left: '-9999px',
        width: '1px',
        height: '1px',
    });
    document.body.appendChild(adBait);
    
    const timer = setTimeout(() => {
        const detected = adBait.offsetHeight === 0;
        if (detected) {
            onDetected(true);
            setIsVisible(true);
        }
        document.body.removeChild(adBait);
    }, 300);

    return () => {
        clearTimeout(timer);
        if (document.body.contains(adBait)) {
            document.body.removeChild(adBait);
        }
    };
  }, [onDetected]);

  if (!isVisible) {
    return null;
  }

  // Adiciona o elemento de isca para que o App.tsx não precise fazer isso
  useEffect(() => {
    const adBait = document.createElement('div');
    adBait.className = 'adsbox';
    document.body.appendChild(adBait);
    return () => {
      if (document.body.contains(adBait)) {
        document.body.removeChild(adBait);
      }
    };
  }, []);

  return (
    <div className="bg-yellow-100 border-b border-yellow-300 text-yellow-800 p-3">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <AlertTriangle className="h-5 w-5 mr-3" />
          <p className="text-sm font-medium">
            <strong>Bloqueador de Anúncios Detectado.</strong> O AJUDAMEDIKO é mantido pelos anúncios que você vê aqui. Por favor, considere desativar seu bloqueador para este site para nos apoiar.
          </p>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          aria-label="Fechar aviso"
          className="p-1 rounded-md hover:bg-yellow-200 focus:outline-none focus:ring-2 focus:ring-yellow-500"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default AdBlockerDetector;